export interface EngineDrawRecord {
  id: string;
  state: string;
  game: string;
  date: string;
  period: string;
  time_local?: string;
  timezone?: string;
  result: string;
  numbers: string[];
  source_updated_at?: string;
  correction_version?: number;
  schedule_version?: string;
  is_canonical?: boolean;
  provenance?: string[];
}

export interface EngineResponse {
  meta: {
    state: string;
    game: string;
    date_from: string;
    date_to: string;
    count: number;
    engine_version?: string;
    page?: number;
    pages?: number;
  };
  draws: EngineDrawRecord[];
}

export async function fetchEngineDraws(params: {
  state: string;
  game: string;
  from: string;
  to: string;
}): Promise<EngineResponse> {
  const baseUrl =
    process.env.LOTTERY_ENGINE_URL ||
    process.env.NEXT_PUBLIC_LOTTERY_ENGINE_URL ||
    'https://lottery-engine-production.up.railway.app';

  const url = new URL('/api/v1/results', baseUrl);
  url.searchParams.set('state', params.state);
  url.searchParams.set('game', params.game);
  url.searchParams.set('from', params.from);
  url.searchParams.set('to', params.to);

  const headers: Record<string, string> = {
    Accept: 'application/json',
    'X-Sync-Client': 'four-pillars-research',
  };

  const token =
    process.env.LOTTERY_ENGINE_TOKEN || process.env.LOTTERY_ENGINE_API_KEY;
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(url.toString(), {
    method: 'GET',
    headers,
    cache: 'no-store',
  });

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(
      `Engine fetch failed ${res.status} ${res.statusText}: ${body.slice(0, 200)}`
    );
  }

  return res.json() as Promise<EngineResponse>;
}

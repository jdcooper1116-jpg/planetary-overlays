# Four Pillars — Phase 1 Micro-Pilot

State: New York | Game: Pick 3 | Window: 2024-01-01 → 2024-01-31

---

## Install

```bash
npm install astronomy-engine
```

Add to `next.config.js` if you get edge-runtime complaints:
```js
module.exports = {
  experimental: {
    serverComponentsExternalPackages: ['astronomy-engine'],
  },
};
```

---

## Environment Variables (.env.local)

```bash
# Railway lottery-engine
LOTTERY_ENGINE_URL=https://lottery-engine-production.up.railway.app
LOTTERY_ENGINE_TOKEN=your_token_here        # optional, only if engine is protected

# Firebase Admin SDK — use whichever pattern your admin.ts already supports
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxx@your-project.iam.gserviceaccount.com
FIREBASE_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\n...\n-----END RSA PRIVATE KEY-----\n"
# OR: FIREBASE_SERVICE_ACCOUNT_KEY={"type":"service_account",...}
```

---

## Pilot Run Order

Run these in order against `http://localhost:3000` (or your deployed Vercel URL):

```bash
BASE=http://localhost:3000

# 1. Seed NY jurisdiction + ny_pick3 game
curl -s -X POST $BASE/api/four-pillars/seed | jq

# 2. Mirror NY Pick 3 Jan 2024 draws from lottery-engine
curl -s -X POST $BASE/api/four-pillars/sync-draws \
  -H "Content-Type: application/json" \
  -d '{"state":"NY","game":"pick3","date_from":"2024-01-01","date_to":"2024-01-31"}' | jq

# 3. Build celestial overlays
curl -s -X POST $BASE/api/four-pillars/build-overlays \
  -H "Content-Type: application/json" \
  -d '{"game_id":"ny_pick3","date_from":"2024-01-01","date_to":"2024-01-31"}' | jq

# 4. Build symbolic features
curl -s -X POST $BASE/api/four-pillars/build-features \
  -H "Content-Type: application/json" \
  -d '{"game_id":"ny_pick3","date_from":"2024-01-01","date_to":"2024-01-31"}' | jq

# 5. Seed starter hypotheses
curl -s -X POST $BASE/api/four-pillars/seed-hypotheses | jq

# 6. Run backtest (evaluates 3 hypotheses × ~62 draws)
curl -s -X POST $BASE/api/four-pillars/run-backtest \
  -H "Content-Type: application/json" \
  -d '{"game_id":"ny_pick3","date_from":"2024-01-01","date_to":"2024-01-31"}' | jq

# 7. Generate forecast for Feb 1 2024 midday
curl -s -X POST $BASE/api/four-pillars/refresh-forecasts \
  -H "Content-Type: application/json" \
  -d '{
    "game_id": "ny_pick3",
    "jurisdiction_id": "ny",
    "target_draw_date": "2024-02-01",
    "target_draw_label": "midday",
    "target_draw_time_utc": "2024-02-01T17:20:00Z"
  }' | jq

# Check status at any point
curl -s $BASE/api/four-pillars/pilot-status | jq
```

---

## File Tree

```
src/
  lib/fourPillars/
    constants/
      versions.ts               ← version constants for all layers
      normalization.ts          ← draw label normalization + ID builder
    jobs/
      jobRunner.ts              ← createJob / updateJob helpers
    seed/
      seedData.ts               ← NY jurisdiction + ny_pick3 seed + writer
    sync/
      engineClient.ts           ← fetch draws from lottery-engine
      drawMapper.ts             ← map engine draw → mirrored draw
      syncDraws.ts              ← SYNC_DRAWS job logic
    overlays/
      celestialEngine.ts        ← astronomy-engine ephemeris computation
      buildOverlays.ts          ← BUILD_OVERLAYS job logic
    features/
      symbolicEngine.ts         ← weekday, moon, sun, numerology, Vedic
      buildSymbolicFeatures.ts  ← BUILD_SYMBOLIC_FEATURES job logic
    hypotheses/
      starterHypotheses.ts      ← 3 Phase 1 hypothesis definitions
      seedHypotheses.ts         ← write hypotheses to Firestore
    evidence/
      evaluator.ts              ← condition interpreter + hypothesis evaluator
      runBacktest.ts            ← RUN_BACKTEST job logic
    forecast/
      forecastEngine.ts         ← evidence-gated forecast generator
  app/api/four-pillars/
    seed/route.ts
    sync-draws/route.ts
    build-overlays/route.ts
    build-features/route.ts
    seed-hypotheses/route.ts
    run-backtest/route.ts
    refresh-forecasts/route.ts
    pilot-status/route.ts
```

---

## Phase 1 Deferred (not built yet)

- Pick 4, multi-state
- Full gematria / Kabbalah / Chaldean / Hebrew-letter systems
- Aspect computation in overlays (active_aspects = [] stub)
- Full 3-digit candidate assembly (forecast returns positional hints only)
- Observation / pattern mining engine
- Auto-hypothesis discovery
- UI, Auth, Firebase Functions, large-scale export

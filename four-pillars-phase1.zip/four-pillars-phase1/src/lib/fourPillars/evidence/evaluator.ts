export type EvidenceResult = 'support' | 'contradiction' | 'neutral' | 'inconclusive';

// ── Condition interpreter ─────────────────────────────────────────────────────
// Supported patterns in trigger_logic / expected_logic:
//
//   { "key": "value" }          → exact string equality
//   { "key": 123 }              → exact number equality
//   { "key_gte": 15 }           → features[key] >= 15
//   { "key_lte": 5 }            → features[key] <= 5
//   { "key_in": ["a", "b"] }    → features[key] is in the list
//
// All conditions are AND — every key-value pair must match.
// Returns: true (all match), false (at least one fails), null (data missing → inconclusive)

function evaluateConditions(
  conditions: Record<string, unknown>,
  features: Record<string, unknown>
): true | false | null {
  for (const [condKey, condValue] of Object.entries(conditions)) {
    if (condKey.endsWith('_gte')) {
      const featureKey = condKey.slice(0, -4);
      if (features[featureKey] === undefined || features[featureKey] === null) return null;
      if ((features[featureKey] as number) < (condValue as number)) return false;
    } else if (condKey.endsWith('_lte')) {
      const featureKey = condKey.slice(0, -4);
      if (features[featureKey] === undefined || features[featureKey] === null) return null;
      if ((features[featureKey] as number) > (condValue as number)) return false;
    } else if (condKey.endsWith('_in')) {
      const featureKey = condKey.slice(0, -3);
      if (features[featureKey] === undefined || features[featureKey] === null) return null;
      if (!(condValue as unknown[]).includes(features[featureKey])) return false;
    } else {
      // Exact equality
      if (features[condKey] === undefined) return null; // missing feature → inconclusive
      if (features[condKey] !== condValue) return false;
    }
  }
  return true;
}

export function evaluateHypothesis(
  triggerLogic: Record<string, unknown>,
  expectedLogic: Record<string, unknown>,
  features: Record<string, unknown>
): {
  result: EvidenceResult;
  trigger_met: boolean | null;
  outcome_met: boolean | null;
} {
  const triggerResult = evaluateConditions(triggerLogic, features);

  if (triggerResult === null) {
    return { result: 'inconclusive', trigger_met: null, outcome_met: null };
  }

  if (triggerResult === false) {
    // Trigger did not fire — hypothesis does not apply to this draw
    return { result: 'neutral', trigger_met: false, outcome_met: null };
  }

  // Trigger fired — check expected outcome
  const outcomeResult = evaluateConditions(expectedLogic, features);

  if (outcomeResult === null) {
    return { result: 'inconclusive', trigger_met: true, outcome_met: null };
  }

  return {
    result: outcomeResult ? 'support' : 'contradiction',
    trigger_met: true,
    outcome_met: outcomeResult,
  };
}

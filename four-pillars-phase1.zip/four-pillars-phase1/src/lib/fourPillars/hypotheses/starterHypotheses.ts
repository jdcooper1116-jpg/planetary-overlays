import { RULE_VERSION } from '../constants/versions';

export interface HypothesisDefinition {
  hypothesis_id: string;
  title: string;
  description: string;
  system_family: string;
  system_name: string;
  jurisdiction_ids: string[];
  game_ids: string[];
  draw_labels: string[];
  trigger_logic: Record<string, unknown>;
  expected_logic: Record<string, unknown>;
  rule_version: string;
  status: string;
  auto_generated: boolean;
}

// ── Phase 1 starter set ───────────────────────────────────────────────────────
// These are research hypotheses to be evaluated — NOT validated picks.
// Each is narrow, testable, and tied to a single symbolic system.

export const STARTER_HYPOTHESES: HypothesisDefinition[] = [
  {
    hypothesis_id: 'hyp_p1_scorpio_moon_digit3_is_8',
    title: 'Scorpio Moon → digit in position 3 is 8',
    description:
      'When the Moon is in Scorpio at draw time, the third digit of the NY Pick 3 result is 8. ' +
      'Scorpio is associated with transformation and depth; 8 maps to Saturn/Scorpio in Vedic systems.',
    system_family: 'astrology',
    system_name: 'moon_sign_positional',
    jurisdiction_ids: ['ny'],
    game_ids: ['ny_pick3'],
    draw_labels: ['midday', 'evening'],
    // trigger_logic: all conditions must be true (AND)
    trigger_logic: { moon_sign: 'Scorpio' },
    // expected_logic: checked only when trigger fires
    expected_logic: { digit_3: '8' },
    rule_version: RULE_VERSION,
    status: 'testing',
    auto_generated: false,
  },
  {
    hypothesis_id: 'hyp_p1_full_moon_digit_root_9',
    title: 'Full Moon draws produce digit root 9',
    description:
      'During Full Moon windows, the three digits of NY Pick 3 reduce to a digit root of 9. ' +
      '9 represents completion in numerology; the Full Moon represents culmination.',
    system_family: 'astrology',
    system_name: 'moon_phase_numerology',
    jurisdiction_ids: ['ny'],
    game_ids: ['ny_pick3'],
    draw_labels: ['midday', 'evening'],
    trigger_logic: { moon_phase_name: 'Full Moon' },
    expected_logic: { digit_root: 9 },
    rule_version: RULE_VERSION,
    status: 'testing',
    auto_generated: false,
  },
  {
    hypothesis_id: 'hyp_p1_saturn_day_digit_sum_gte_15',
    title: 'Saturday (Saturn day) → digit sum ≥ 15',
    description:
      'On Saturdays, ruled by Saturn (Vedic number 8), the three digits sum to 15 or higher. ' +
      'Saturn rules concentration and accumulation, reflected in higher total digit values.',
    system_family: 'numerology',
    system_name: 'weekday_ruler_digit_family',
    jurisdiction_ids: ['ny'],
    game_ids: ['ny_pick3'],
    draw_labels: ['midday', 'evening'],
    trigger_logic: { weekday_name: 'Saturday' },
    // digit_sum_gte is a special operator: features.digit_sum >= 15
    expected_logic: { digit_sum_gte: 15 },
    rule_version: RULE_VERSION,
    status: 'testing',
    auto_generated: false,
  },
];

import { NextRequest, NextResponse } from 'next/server';
import { readDrawById } from '@/lib/fourPillars/readers/drawsReader';

export async function GET(
  _req: NextRequest,
  { params }: { params: { drawId: string } }
) {
  try {
    const result = await readDrawById(params.drawId);
    if (!result.draw) {
      return NextResponse.json({ ok: false, error: 'Draw not found' }, { status: 404 });
    }
    return NextResponse.json({ ok: true, ...result });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : String(err) },
      { status: 500 }
    );
  }
}

'use client';

import { useState } from 'react';

interface JobRunnerCardProps {
  title: string;
  description: string;
  endpoint: string;
  body?: Record<string, unknown>;
  color?: 'indigo' | 'amber' | 'green' | 'rose' | 'sky';
}

const BUTTON_COLORS = {
  indigo: 'bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-900',
  amber: 'bg-amber-600 hover:bg-amber-500 disabled:bg-amber-900',
  green: 'bg-green-700 hover:bg-green-600 disabled:bg-green-900',
  rose: 'bg-rose-700 hover:bg-rose-600 disabled:bg-rose-900',
  sky: 'bg-sky-600 hover:bg-sky-500 disabled:bg-sky-900',
};

export default function JobRunnerCard({
  title,
  description,
  endpoint,
  body,
  color = 'indigo',
}: JobRunnerCardProps) {
  const [status, setStatus] = useState<'idle' | 'running' | 'done' | 'error'>('idle');
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    setStatus('running');
    setResult(null);
    setError(null);
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: body ? JSON.stringify(body) : undefined,
      });
      const data = await res.json();
      if (data.ok === false) {
        setError(data.error ?? 'Unknown error');
        setStatus('error');
      } else {
        setResult(data);
        setStatus('done');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setStatus('error');
    }
  }

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-gray-800 flex items-start justify-between gap-4">
        <div>
          <div className="text-sm font-semibold text-gray-100 mb-0.5">{title}</div>
          <div className="text-xs text-gray-500">{description}</div>
        </div>
        <button
          onClick={run}
          disabled={status === 'running'}
          className={`flex-shrink-0 px-4 py-2 text-sm font-medium text-white rounded-lg transition-colors ${
            BUTTON_COLORS[color]
          } disabled:cursor-not-allowed`}
        >
          {status === 'running' ? (
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 border border-white/40 border-t-white rounded-full animate-spin inline-block" />
              Running…
            </span>
          ) : (
            'Run'
          )}
        </button>
      </div>

      {/* Result area */}
      {status !== 'idle' && (
        <div className="px-5 py-4">
          {status === 'running' && (
            <p className="text-xs text-gray-500 font-mono animate-pulse">
              Calling {endpoint}…
            </p>
          )}
          {status === 'error' && (
            <div className="text-xs text-rose-400 font-mono bg-rose-950/30 border border-rose-900/40 rounded p-3">
              Error: {error}
            </div>
          )}
          {status === 'done' && result && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs text-green-400 font-mono">✓ Completed</span>
                <span className="text-xs text-gray-600 font-mono">
                  {new Date().toLocaleTimeString()}
                </span>
              </div>
              <pre className="text-xs text-gray-300 font-mono bg-gray-800/60 rounded p-3 overflow-auto max-h-48">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}

      {/* Endpoint label */}
      <div className="px-5 py-2 bg-gray-800/20 border-t border-gray-800/50">
        <span className="text-xs text-gray-600 font-mono">POST {endpoint}</span>
      </div>
    </div>
  );
}

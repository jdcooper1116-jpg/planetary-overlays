import { readCandidateById } from '@/lib/fourPillars/readers/candidateReader';
import { readValidationRuns } from '@/lib/fourPillars/readers/validationRunReader';
import { readObservationById } from '@/lib/fourPillars/readers/observationReader';
import KeyValueBlock from '@/components/phase2/KeyValueBlock';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { PROMOTION_THRESHOLDS } from '@/lib/fourPillars/autoHypotheses/scoring';

export const revalidate = 30;

interface PageProps {
  params: { candidateId: string };
}

const STATUS_STYLE: Record<string, string> = {
  candidate: 'text-sky-300 bg-sky-950/40 border-sky-800/50',
  testing: 'text-green-300 bg-green-950/40 border-green-800/50',
  rejected: 'text-rose-300 bg-rose-950/40 border-rose-800/50',
};

const REC_STYLE: Record<string, string> = {
  promote_to_testing: 'text-green-400',
  borderline: 'text-amber-400',
  reject: 'text-rose-400',
  no_trigger_fired: 'text-gray-500',
};

export default async function CandidateDetailPage({ params }: PageProps) {
  const [candidate, validationRuns] = await Promise.all([
    readCandidateById(params.candidateId),
    readValidationRuns(params.candidateId),
  ]);

  if (!candidate) notFound();

  const obs_id = candidate.observation_id as string | null;
  const observation = obs_id ? await readObservationById(obs_id) : null;

  const t = PROMOTION_THRESHOLDS;

  // Promotion eligibility check against latest validation
  const vsr = candidate.validated_support_rate as number | null;
  const vlift = candidate.validated_lift as number | null;
  const vfired = (candidate.validated_trigger_fired_count as number) ?? 0;
  const vcontra = (candidate.validated_contradiction_count as number) ?? 0;
  const contra_rate = vfired > 0 ? vcontra / vfired : 0;

  const checks = [
    {
      label: `trigger_fired ≥ ${t.min_trigger_fired}`,
      passed: vfired >= t.min_trigger_fired,
      value: String(vfired),
    },
    {
      label: `support_rate ≥ ${t.min_support_rate * 100}%`,
      passed: vsr !== null && vsr >= t.min_support_rate,
      value: vsr !== null ? `${Math.round(vsr * 100)}%` : '—',
    },
    {
      label: `lift ≥ ${t.min_lift}×`,
      passed: vlift !== null && vlift >= t.min_lift,
      value: vlift !== null ? `${vlift.toFixed(2)}×` : '—',
    },
    {
      label: `contradiction_rate ≤ ${t.max_contradiction_rate * 100}%`,
      passed: contra_rate <= t.max_contradiction_rate,
      value: `${Math.round(contra_rate * 100)}%`,
    },
  ];

  const allPassed = checks.every((c) => c.passed);

  return (
    <div className="px-8 py-8 max-w-5xl">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm font-mono text-gray-600">
        <Link href="/phase4/candidates" className="text-indigo-400 hover:text-indigo-300">candidates</Link>
        {' '}/{' '}
        <span className="text-gray-400">{candidate.candidate_id as string}</span>
      </div>

      {/* Hero */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl px-6 py-5 mb-8">
        <div className="flex items-start justify-between gap-4 flex-wrap mb-3">
          <div>
            <div className="text-xs text-gray-600 font-mono mb-1">{candidate.candidate_id as string}</div>
            <h1 className="text-lg font-bold text-gray-100 mb-1">{candidate.title as string}</h1>
            <p className="text-sm text-gray-400">{candidate.description as string}</p>
          </div>
          <div className="flex flex-col gap-2 items-end flex-shrink-0">
            <span className={`px-2.5 py-1 text-xs rounded border font-mono ${
              STATUS_STYLE[candidate.status as string] ?? 'text-gray-400 border-gray-700'
            }`}>
              {candidate.status as string}
            </span>
            {candidate.last_recommendation && (
              <span className={`text-xs font-mono ${REC_STYLE[candidate.last_recommendation as string] ?? 'text-gray-500'}`}>
                rec: {candidate.last_recommendation as string}
              </span>
            )}
          </div>
        </div>

        {/* Key metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4">
          {[
            { label: 'confidence_score', value: (candidate.confidence_score as number)?.toFixed(3) ?? '—', cls: 'text-indigo-300' },
            { label: 'confidence_label', value: candidate.confidence_label as string, cls: 'text-sky-300' },
            { label: 'validated_lift', value: vlift ? `${vlift.toFixed(2)}×` : '—', cls: 'text-emerald-300' },
            { label: 'support_rate', value: vsr ? `${Math.round(vsr * 100)}%` : '—', cls: 'text-green-300' },
            { label: 'trigger_fired', value: String(vfired), cls: 'text-amber-300' },
          ].map(({ label, value, cls }) => (
            <div key={label} className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs text-gray-600 font-mono mb-1">{label}</div>
              <div className={`text-lg font-bold font-mono ${cls}`}>{value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Promotion eligibility */}
      <div className="mb-8 bg-gray-900 border border-gray-800 rounded-xl px-6 py-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="text-sm font-semibold text-gray-200">Promotion Eligibility</div>
          <span className={`px-2 py-0.5 text-xs rounded border font-mono ${
            allPassed
              ? 'text-green-300 border-green-800/50 bg-green-950/30'
              : 'text-rose-300 border-rose-800/50 bg-rose-950/30'
          }`}>
            {allPassed ? '✓ Eligible' : '✗ Not eligible'}
          </span>
        </div>
        <div className="space-y-2">
          {checks.map((check) => (
            <div key={check.label} className="flex items-center gap-3 text-sm">
              <span className={check.passed ? 'text-green-400' : 'text-rose-400'}>
                {check.passed ? '✓' : '✗'}
              </span>
              <span className="text-gray-400 font-mono text-xs flex-1">{check.label}</span>
              <span className="text-gray-200 font-mono text-xs">{check.value}</span>
            </div>
          ))}
        </div>
        {!allPassed && (
          <p className="mt-4 text-xs text-gray-600 font-mono">
            Run validate-candidates and then promote-candidates from the{' '}
            <Link href="/phase4/promotion" className="text-indigo-400 hover:text-indigo-300">Promotion page</Link>.
          </p>
        )}
      </div>

      {/* Logic */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div>
          <div className="text-xs text-gray-500 font-mono uppercase tracking-wide mb-2">Trigger Logic</div>
          <pre className="text-xs text-indigo-300 font-mono bg-gray-900 border border-gray-800 rounded p-4 overflow-auto">
            {JSON.stringify(candidate.trigger_logic, null, 2)}
          </pre>
        </div>
        <div>
          <div className="text-xs text-gray-500 font-mono uppercase tracking-wide mb-2">Expected Logic</div>
          <pre className="text-xs text-green-300 font-mono bg-gray-900 border border-gray-800 rounded p-4 overflow-auto">
            {JSON.stringify(candidate.expected_logic, null, 2)}
          </pre>
        </div>
      </div>

      {/* Source observation */}
      {observation && (
        <div className="mb-8">
          <KeyValueBlock
            title="Source Observation"
            rows={[
              { label: 'observation_id', value: observation.observation_id },
              { label: 'pattern_family', value: observation.pattern_family },
              { label: 'trigger', value: `${observation.trigger_field}=${observation.trigger_value}` },
              { label: 'outcome', value: `${observation.outcome_field}=${observation.outcome_label}` },
              { label: 'sample_size', value: observation.sample_size },
              { label: 'observed_count', value: observation.observed_count },
              { label: 'observed_rate', value: `${Math.round((observation.observed_rate as number) * 100)}%` },
              { label: 'baseline_rate', value: `${Math.round((observation.baseline_rate as number) * 100)}%` },
              { label: 'lift', value: `${(observation.lift as number).toFixed(2)}×` },
            ]}
          />
        </div>
      )}

      {/* Scoring components */}
      <div className="mb-8">
        <KeyValueBlock
          title="Scoring Breakdown"
          rows={[
            { label: 'confidence_score', value: candidate.confidence_score },
            { label: 'confidence_label', value: candidate.confidence_label },
            { label: 'lift_component (40% weight)', value: candidate.lift_component },
            { label: 'sample_component (30% weight)', value: candidate.sample_component },
            { label: 'rate_component (30% weight)', value: candidate.rate_component },
          ]}
        />
      </div>

      {/* Validation history */}
      <div>
        <div className="text-sm font-semibold text-gray-200 mb-3">
          Validation Runs ({validationRuns.length})
        </div>
        {validationRuns.length === 0 ? (
          <p className="text-gray-600 text-sm font-mono">No validation runs yet.</p>
        ) : (
          <div className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-800">
                    {['Run ID', 'Draws', 'Fired', 'Support', 'Contra', 'Rate', 'Lift', 'Rec'].map((h) => (
                      <th key={h} className="px-3 py-2.5 text-left text-xs text-gray-600 font-mono font-normal uppercase">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800/50">
                  {validationRuns.map((vr) => (
                    <tr key={vr.validation_run_id as string} className="hover:bg-gray-800/30">
                      <td className="px-3 py-2 font-mono text-xs text-gray-600 max-w-[160px] truncate">{vr.validation_run_id as string}</td>
                      <td className="px-3 py-2 font-mono text-xs text-gray-400">{String(vr.draws_evaluated)}</td>
                      <td className="px-3 py-2 font-mono text-xs text-sky-300">{String(vr.trigger_fired_count)}</td>
                      <td className="px-3 py-2 font-mono text-xs text-green-400">{String(vr.support_count)}</td>
                      <td className="px-3 py-2 font-mono text-xs text-rose-400">{String(vr.contradiction_count)}</td>
                      <td className="px-3 py-2 font-mono text-xs text-gray-200">
                        {vr.support_rate_on_fired !== null ? `${Math.round((vr.support_rate_on_fired as number) * 100)}%` : '—'}
                      </td>
                      <td className="px-3 py-2 font-mono text-xs text-emerald-300">
                        {vr.validated_lift !== null ? `${(vr.validated_lift as number).toFixed(2)}×` : '—'}
                      </td>
                      <td className={`px-3 py-2 font-mono text-xs ${REC_STYLE[vr.recommendation as string] ?? 'text-gray-400'}`}>
                        {vr.recommendation as string}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

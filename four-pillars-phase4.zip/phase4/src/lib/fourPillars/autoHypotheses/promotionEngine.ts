import { getAdminDb } from '@/lib/firebase/admin';
import { FieldValue } from 'firebase-admin/firestore';
import { PILOT_GAME_ID, serializeDoc } from '../readers/pilotConstants';
import { meetsPromotionThresholds, PROMOTION_THRESHOLDS } from './scoring';
import { RULE_VERSION } from '../constants/versions';

export interface PromotionResult {
  job_id: string;
  candidates_evaluated: number;
  promoted_to_testing: number;
  rejected: number;
  skipped_no_validation: number;
  errors: number;
  promoted_ids: string[];
  rejected_ids: string[];
}

export async function runPromotionEngine(): Promise<PromotionResult> {
  const db = getAdminDb();

  const jobId = `PROMOTE_CANDIDATES_${Date.now()}`;
  await db.collection('jobs').doc(jobId).set({
    job_id: jobId,
    job_type: 'PROMOTE_CANDIDATES',
    status: 'running',
    triggered_by: 'phase4',
    records_processed: 0,
    records_failed: 0,
    error_summary: null,
    created_at: FieldValue.serverTimestamp(),
    updated_at: FieldValue.serverTimestamp(),
  });

  let candidates_evaluated = 0;
  let promoted_to_testing = 0;
  let rejected = 0;
  let skipped_no_validation = 0;
  let errors = 0;
  const promoted_ids: string[] = [];
  const rejected_ids: string[] = [];

  try {
    // Load candidates that are in 'candidate' status and have been validated
    const candSnap = await db
      .collection('auto_hypothesis_queue')
      .where('game_id', '==', PILOT_GAME_ID)
      .where('status', '==', 'candidate')
      .get();

    const candidates = candSnap.docs.map((d) => ({ ref: d.ref, ...serializeDoc(d.data()) }));

    for (const cand of candidates) {
      candidates_evaluated++;

      // Must have been validated at least once
      if (!cand.last_validation_id || cand.validated_trigger_fired_count === undefined) {
        skipped_no_validation++;
        continue;
      }

      const trigger_fired = cand.validated_trigger_fired_count as number;
      const support_rate = cand.validated_support_rate as number | null;
      const lift = cand.validated_lift as number | null;
      const contradiction_count = cand.validated_contradiction_count as number ?? 0;

      if (trigger_fired === 0 || support_rate === null || lift === null) {
        // No trigger ever fired — not enough data to promote or reject
        // Leave in candidate status but record why
        await cand.ref.update({
          promotion_decision: 'insufficient_data',
          promotion_reason: 'Trigger never fired in pilot dataset.',
          updated_at: FieldValue.serverTimestamp(),
        });
        continue;
      }

      const contradiction_rate = trigger_fired > 0 ? contradiction_count / trigger_fired : 0;

      const { eligible, reason } = meetsPromotionThresholds({
        trigger_fired_count: trigger_fired,
        support_rate_on_fired: support_rate,
        lift,
        contradiction_rate,
      });

      try {
        if (eligible) {
          // Promote: write to hypothesis_registry as status='testing'
          const registry_id = `auto_${cand.candidate_id}`;
          const regRef = db.collection('hypothesis_registry').doc(registry_id);
          const regSnap = await regRef.get();

          if (!regSnap.exists) {
            await regRef.set({
              hypothesis_id: registry_id,
              source: 'auto_observation',
              candidate_id: cand.candidate_id,
              observation_id: cand.observation_id,
              title: cand.title,
              description: cand.description,
              system_family: `auto_${cand.pattern_family}`,
              system_name: cand.pattern_family,
              jurisdiction_ids: ['ny'],
              game_ids: [PILOT_GAME_ID],
              draw_labels: ['midday', 'evening'],
              trigger_logic: cand.trigger_logic,
              expected_logic: cand.expected_logic,
              rule_version: RULE_VERSION,
              status: 'testing',
              auto_generated: true,
              confidence_score: cand.confidence_score,
              confidence_label: cand.confidence_label,
              validated_support_rate: support_rate,
              validated_lift: lift,
              evidence_count_supporting: 0,
              evidence_count_contradicting: 0,
              evidence_count_neutral: 0,
              evidence_count_total: 0,
              support_rate: null,
              last_tested_at: null,
              promoted_at: FieldValue.serverTimestamp(),
              created_at: FieldValue.serverTimestamp(),
              updated_at: FieldValue.serverTimestamp(),
            });
          }

          // Update candidate status
          await cand.ref.update({
            status: 'testing',
            promotion_decision: 'promoted_to_testing',
            promotion_reason: reason,
            registry_id,
            promoted_at: FieldValue.serverTimestamp(),
            updated_at: FieldValue.serverTimestamp(),
          });

          promoted_to_testing++;
          promoted_ids.push(cand.candidate_id as string);
        } else {
          // Reject — but keep in queue for audit trail
          await cand.ref.update({
            status: 'rejected',
            promotion_decision: 'rejected',
            promotion_reason: reason,
            rejected_at: FieldValue.serverTimestamp(),
            updated_at: FieldValue.serverTimestamp(),
          });

          rejected++;
          rejected_ids.push(cand.candidate_id as string);
        }
      } catch (err) {
        console.error('promotion error', cand.candidate_id, err);
        errors++;
      }
    }

    await db.collection('jobs').doc(jobId).update({
      status: 'completed',
      records_processed: candidates_evaluated,
      records_failed: errors,
      updated_at: FieldValue.serverTimestamp(),
    });

    return {
      job_id: jobId,
      candidates_evaluated,
      promoted_to_testing,
      rejected,
      skipped_no_validation,
      errors,
      promoted_ids,
      rejected_ids,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await db.collection('jobs').doc(jobId).update({
      status: 'failed',
      error_summary: msg.slice(0, 500),
      updated_at: FieldValue.serverTimestamp(),
    });
    throw err;
  }
}

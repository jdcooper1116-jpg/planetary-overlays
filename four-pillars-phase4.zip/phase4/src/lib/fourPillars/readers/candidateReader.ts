import { getAdminDb } from '@/lib/firebase/admin';
import { PILOT_GAME_ID, serializeDoc } from './pilotConstants';

export interface CandidateFilter {
  status?: string;
  confidence_label?: string;
  pattern_family?: string;
  recommendation?: string;
}

export async function readCandidates(filter: CandidateFilter = {}): Promise<Record<string, unknown>[]> {
  const db = getAdminDb();

  let q = db
    .collection('auto_hypothesis_queue')
    .where('game_id', '==', PILOT_GAME_ID)
    .orderBy('confidence_score', 'desc');

  const snap = await q.get();
  let docs = snap.docs.map((d) => serializeDoc(d.data()));

  if (filter.status) docs = docs.filter((d) => d.status === filter.status);
  if (filter.confidence_label) docs = docs.filter((d) => d.confidence_label === filter.confidence_label);
  if (filter.pattern_family) docs = docs.filter((d) => d.pattern_family === filter.pattern_family);
  if (filter.recommendation) docs = docs.filter((d) => d.last_recommendation === filter.recommendation);

  return docs;
}

export async function readCandidateById(id: string): Promise<Record<string, unknown> | null> {
  const db = getAdminDb();
  const snap = await db.collection('auto_hypothesis_queue').doc(id).get();
  return snap.exists ? serializeDoc(snap.data()!) : null;
}

export async function readCandidateStats(): Promise<{
  total: number;
  by_status: Record<string, number>;
  by_label: Record<string, number>;
  promoted: number;
  rejected: number;
}> {
  const db = getAdminDb();
  const snap = await db.collection('auto_hypothesis_queue').where('game_id', '==', PILOT_GAME_ID).get();
  const docs = snap.docs.map((d) => serializeDoc(d.data()));

  const by_status: Record<string, number> = {};
  const by_label: Record<string, number> = {};
  let promoted = 0;
  let rejected = 0;

  for (const d of docs) {
    const s = d.status as string ?? 'unknown';
    by_status[s] = (by_status[s] ?? 0) + 1;

    const l = d.confidence_label as string ?? 'unknown';
    by_label[l] = (by_label[l] ?? 0) + 1;

    if (s === 'testing') promoted++;
    if (s === 'rejected') rejected++;
  }

  return { total: docs.length, by_status, by_label, promoted, rejected };
}

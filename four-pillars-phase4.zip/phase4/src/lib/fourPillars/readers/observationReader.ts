import { getAdminDb } from '@/lib/firebase/admin';
import { PILOT_GAME_ID, serializeDoc } from './pilotConstants';

export interface ObservationFilter {
  family?: string;
  lift_gte?: number;
  candidate_status?: string;
}

export async function readObservations(filter: ObservationFilter = {}): Promise<Record<string, unknown>[]> {
  const db = getAdminDb();

  let q = db
    .collection('observation_log')
    .where('game_id', '==', PILOT_GAME_ID)
    .orderBy('lift', 'desc');

  const snap = await q.get();
  let docs = snap.docs.map((d) => serializeDoc(d.data()));

  if (filter.family) docs = docs.filter((d) => d.pattern_family === filter.family);
  if (filter.lift_gte !== undefined) docs = docs.filter((d) => (d.lift as number) >= filter.lift_gte!);
  if (filter.candidate_status) docs = docs.filter((d) => d.candidate_status === filter.candidate_status);

  return docs;
}

export async function readObservationById(id: string): Promise<Record<string, unknown> | null> {
  const db = getAdminDb();
  const snap = await db.collection('observation_log').doc(id).get();
  return snap.exists ? serializeDoc(snap.data()!) : null;
}

export async function readObservationStats(): Promise<{
  total: number;
  by_family: Record<string, number>;
  top_lift: number;
  median_lift: number;
}> {
  const db = getAdminDb();
  const snap = await db.collection('observation_log').where('game_id', '==', PILOT_GAME_ID).get();
  const docs = snap.docs.map((d) => serializeDoc(d.data()));

  const lifts = docs.map((d) => d.lift as number).sort((a, b) => a - b);
  const by_family: Record<string, number> = {};
  for (const d of docs) {
    const f = d.pattern_family as string;
    by_family[f] = (by_family[f] ?? 0) + 1;
  }

  return {
    total: docs.length,
    by_family,
    top_lift: lifts.length > 0 ? lifts[lifts.length - 1] : 0,
    median_lift: lifts.length > 0 ? lifts[Math.floor(lifts.length / 2)] : 0,
  };
}

import { getAdminDb } from '@/lib/firebase/admin';
import { PILOT_GAME_ID, serializeDoc } from './pilotConstants';

export async function readValidationRuns(candidateId?: string): Promise<Record<string, unknown>[]> {
  const db = getAdminDb();

  let q = db
    .collection('candidate_validation_runs')
    .where('game_id', '==', PILOT_GAME_ID)
    .orderBy('created_at', 'desc');

  const snap = await q.get();
  let docs = snap.docs.map((d) => serializeDoc(d.data()));

  if (candidateId) {
    docs = docs.filter((d) => d.candidate_id === candidateId);
  }

  return docs;
}

export async function readValidationRunById(id: string): Promise<Record<string, unknown> | null> {
  const db = getAdminDb();
  const snap = await db.collection('candidate_validation_runs').doc(id).get();
  return snap.exists ? serializeDoc(snap.data()!) : null;
}

import { readCandidateStats } from '@/lib/fourPillars/readers/candidateReader';
import { readObservationStats } from '@/lib/fourPillars/readers/observationReader';
import { readValidationRuns } from '@/lib/fourPillars/readers/validationRunReader';
import { readReviewSummary } from '@/lib/fourPillars/review/reviewEngine';
import JobRunnerCard from '@/components/phase3/JobRunnerCard';
import Link from 'next/link';
import { PROMOTION_THRESHOLDS } from '@/lib/fourPillars/autoHypotheses/scoring';

export const revalidate = 0;

const PIPELINE_STEPS = [
  {
    order: 'Step 1',
    title: 'Run Observation Scan',
    description:
      'Scans symbolic feature docs and detects (trigger → outcome) patterns with lift ≥1.20. ' +
      'Writes to observation_log. Idempotent.',
    endpoint: '/api/four-pillars/phase4/run-observation-scan',
    color: 'indigo' as const,
  },
  {
    order: 'Step 2',
    title: 'Generate Candidates',
    description:
      'Converts top observations into structured candidate hypotheses in auto_hypothesis_queue. ' +
      'Idempotent — re-running updates existing candidates.',
    endpoint: '/api/four-pillars/phase4/generate-candidates',
    color: 'sky' as const,
  },
  {
    order: 'Step 3',
    title: 'Validate Candidates',
    description:
      'Backtests all candidates against the 62 pilot draws. Writes candidate_validation_runs and ' +
      'updates support_rate, lift, and recommendation.',
    endpoint: '/api/four-pillars/phase4/validate-candidates',
    color: 'amber' as const,
  },
  {
    order: 'Step 4',
    title: 'Run Promotion Engine',
    description:
      'Promotes qualifying candidates into hypothesis_registry as status=proposed. ' +
      'IMPORTANT: proposed does NOT mean forecast-active. Manual review and approval are required.',
    endpoint: '/api/four-pillars/phase4/promote-candidates',
    color: 'green' as const,
  },
];

export default async function PromotionPage() {
  const [obsStats, candStats, latestRuns, reviewSummary] = await Promise.all([
    readObservationStats(),
    readCandidateStats(),
    readValidationRuns(),
    readReviewSummary(),
  ]);

  const t = PROMOTION_THRESHOLDS;

  return (
    <div className="px-8 py-8 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-100 mb-1">Promotion Pipeline</h1>
        <p className="text-sm text-gray-500">
          Run discovery → validation → promotion. Then review candidates manually before they can
          participate in forecasting.
        </p>
      </div>

      {/* Hard rule — prominent */}
      <div className="mb-8 bg-indigo-950/30 border border-indigo-800/50 rounded-xl px-6 py-5">
        <div className="text-xs font-mono text-indigo-400 uppercase tracking-wide mb-2">
          Hard Rule — Auto-Generated Hypothesis Forecast Guard
        </div>
        <p className="text-sm text-gray-300 leading-relaxed mb-3">
          Auto-generated hypotheses enter{' '}
          <span className="font-mono text-amber-300">hypothesis_registry</span> as{' '}
          <span className="font-mono text-amber-300">status=proposed</span>.{' '}
          <strong>This does NOT make them forecast-active.</strong>
        </p>
        <p className="text-sm text-gray-400 leading-relaxed mb-4">
          A hypothesis with <span className="font-mono text-indigo-300">auto_generated=true</span> is{' '}
          <strong>excluded from all forecast output</strong> unless a human explicitly sets{' '}
          <span className="font-mono text-green-400">forecast_approved=true</span> via the Review
          Queue. Evidence thresholds still apply independently after approval.
        </p>
        <div className="flex flex-wrap gap-3">
          <Link
            href="/phase4/review-queue"
            className="px-4 py-2 text-sm bg-indigo-700 hover:bg-indigo-600 text-white rounded-lg font-medium transition-colors"
          >
            → Go to Review Queue
          </Link>
          <span className="text-xs text-indigo-400 font-mono self-center">
            {reviewSummary.ready_for_review} candidate{reviewSummary.ready_for_review !== 1 ? 's' : ''} awaiting review
          </span>
        </div>
      </div>

      {/* Lifecycle diagram */}
      <div className="mb-8 bg-gray-900 border border-gray-800 rounded-xl px-6 py-5">
        <div className="text-sm font-semibold text-gray-200 mb-4">Lifecycle</div>
        <div className="flex items-center gap-1 flex-wrap text-xs font-mono">
          {[
            { label: 'candidate', cls: 'text-sky-400' },
            { label: '→' },
            { label: 'validated', cls: 'text-indigo-400' },
            { label: '→' },
            { label: 'proposed', cls: 'text-amber-400', note: '(registry, not forecast-active)' },
            { label: '→' },
            { label: '[human review]', cls: 'text-gray-400' },
            { label: '→' },
            { label: 'testing', cls: 'text-green-400', note: '(forecast_approved=true)' },
          ].map((item, i) =>
            'note' in item ? (
              <span key={i} className={`${item.cls ?? 'text-gray-600'} whitespace-nowrap`}>
                {item.label}{' '}
                <span className="text-gray-700 font-normal">{item.note}</span>
              </span>
            ) : (
              <span key={i} className={item.cls ?? 'text-gray-700'}>{item.label}</span>
            )
          )}
        </div>
        <p className="mt-3 text-xs text-gray-600">
          Rejected candidates remain in both the queue and registry with status=rejected. They are
          never deleted — they exist for permanent audit.
        </p>
      </div>

      {/* Pipeline status summary */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl px-6 py-5 mb-8">
        <div className="text-sm font-semibold text-gray-200 mb-4">Pipeline Status</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          {[
            { label: 'Observations', value: obsStats.total, color: 'text-indigo-400', href: '/phase4/observations' },
            { label: 'Candidates', value: candStats.total, color: 'text-sky-400', href: '/phase4/candidates' },
            { label: 'Validation Runs', value: latestRuns.length, color: 'text-amber-400', href: '/phase4/validation-runs' },
            { label: 'Ready for Review', value: reviewSummary.ready_for_review, color: 'text-amber-300', href: '/phase4/review-queue' },
          ].map(({ label, value, color, href }) => (
            <Link key={label} href={href} className="bg-gray-800/50 rounded-lg p-4 hover:bg-gray-800 transition-colors text-center">
              <div className={`text-2xl font-bold tabular-nums ${color}`}>{value}</div>
              <div className="text-xs text-gray-500 font-mono mt-1">{label}</div>
            </Link>
          ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Approved', value: reviewSummary.approved, color: 'text-green-400' },
            { label: 'Rejected', value: reviewSummary.rejected, color: 'text-rose-400' },
            { label: 'Proposed (registry)', value: reviewSummary.proposed_in_registry, color: 'text-amber-300' },
            { label: 'Forecast-active', value: reviewSummary.testing_approved_in_registry, color: 'text-emerald-400' },
          ].map(({ label, value, color }) => (
            <div key={label} className="bg-gray-800/30 rounded-lg p-3 text-center">
              <div className={`text-xl font-bold tabular-nums ${color}`}>{value}</div>
              <div className="text-xs text-gray-600 font-mono mt-0.5">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Promotion thresholds */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl px-6 py-4 mb-8">
        <div className="text-sm font-semibold text-gray-200 mb-3">Promotion Thresholds (Step 4)</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
          {[
            { label: 'min trigger_fired', value: `≥ ${t.min_trigger_fired}` },
            { label: 'min support_rate', value: `≥ ${Math.round(t.min_support_rate * 100)}%` },
            { label: 'min lift', value: `≥ ${t.min_lift}×` },
            { label: 'max contradiction', value: `≤ ${Math.round(t.max_contradiction_rate * 100)}%` },
          ].map(({ label, value }) => (
            <div key={label} className="bg-gray-800/50 rounded p-2.5">
              <div className="text-gray-600 mb-0.5">{label}</div>
              <div className="text-indigo-300 font-semibold">{value}</div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-xs text-gray-600">
          These thresholds gate entry into <em>proposed</em> status. They are not the same as
          forecast approval thresholds. Both must be satisfied independently.
        </p>
      </div>

      {/* Pipeline step cards */}
      <div className="space-y-4 mb-8">
        {PIPELINE_STEPS.map((step) => (
          <div key={step.order}>
            <div className="text-xs text-gray-600 font-mono mb-1.5">{step.order}</div>
            <JobRunnerCard
              title={step.title}
              description={step.description}
              endpoint={step.endpoint}
              color={step.color}
            />
          </div>
        ))}
      </div>

      {/* Step 5 callout */}
      <div className="bg-amber-950/20 border border-amber-800/30 rounded-xl px-6 py-5 mb-8">
        <div className="text-sm font-semibold text-amber-300 mb-2">Step 5 — Manual Review (required)</div>
        <p className="text-sm text-gray-400 leading-relaxed mb-3">
          After running Step 4, go to the Review Queue. Each candidate that passed validation
          thresholds appears there. Review its trigger logic, expected logic, support rate, and lift.
          Only approve candidates you believe are genuine signal, not noise.
        </p>
        <Link
          href="/phase4/review-queue"
          className="inline-block px-4 py-2 text-sm bg-amber-800 hover:bg-amber-700 text-white rounded-lg font-medium transition-colors"
        >
          → Go to Review Queue
        </Link>
      </div>

      {/* Navigation */}
      <div className="pt-4 border-t border-gray-800 grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { href: '/phase4/observations', label: '→ Observations' },
          { href: '/phase4/candidates', label: '→ Candidates' },
          { href: '/phase4/validation-runs', label: '→ Validation Runs' },
          { href: '/phase4/review-queue', label: '→ Review Queue' },
        ].map(({ href, label }) => (
          <Link
            key={href}
            href={href}
            className="text-sm text-center px-3 py-2 bg-gray-900 border border-gray-800 rounded-lg text-gray-400 hover:text-gray-200 hover:border-gray-600 font-mono transition-colors"
          >
            {label}
          </Link>
        ))}
      </div>
    </div>
  );
}

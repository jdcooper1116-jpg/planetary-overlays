import { readReviewQueueCandidates } from '@/lib/fourPillars/review/reviewActions';
import { readReviewSummary } from '@/lib/fourPillars/review/reviewEngine';
import CandidateApprovalBadge from '@/components/phase4/CandidateApprovalBadge';
import Link from 'next/link';
import { PROMOTION_THRESHOLDS } from '@/lib/fourPillars/autoHypotheses/scoring';

export const revalidate = 0; // always fresh — review state changes on action

export default async function ReviewQueuePage() {
  const [candidates, summary] = await Promise.all([
    readReviewQueueCandidates(),
    readReviewSummary(),
  ]);

  const t = PROMOTION_THRESHOLDS;

  return (
    <div className="px-8 py-8 max-w-5xl">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-100 mb-1">Review Queue</h1>
        <p className="text-sm text-gray-500">
          Candidates ready for manual review. Only approved candidates can participate in
          forecast generation.
        </p>
      </div>

      {/* Hard rule callout */}
      <div className="mb-8 bg-indigo-950/30 border border-indigo-800/40 rounded-xl px-6 py-4">
        <div className="text-xs font-mono text-indigo-400 uppercase tracking-wide mb-2">
          Forecast Guard Rule
        </div>
        <p className="text-sm text-gray-300 leading-relaxed">
          Any hypothesis where <span className="font-mono text-indigo-300">auto_generated === true</span>{' '}
          is <strong>excluded from forecast output</strong> unless{' '}
          <span className="font-mono text-green-400">forecast_approved === true</span>.
          Approving a candidate here is the only way to allow it into forecasting.
          Evidence thresholds still apply independently.
        </p>
      </div>

      {/* Summary counters */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
        {[
          { label: 'Ready for review', value: summary.ready_for_review, cls: 'text-amber-300' },
          { label: 'Approved', value: summary.approved, cls: 'text-green-400' },
          { label: 'Rejected', value: summary.rejected, cls: 'text-rose-400' },
          { label: 'Needs data', value: summary.needs_more_data, cls: 'text-sky-400' },
          { label: 'Proposed (registry)', value: summary.proposed_in_registry, cls: 'text-gray-400' },
          { label: 'Forecast-active', value: summary.testing_approved_in_registry, cls: 'text-emerald-400' },
        ].map(({ label, value, cls }) => (
          <div key={label} className="bg-gray-900 border border-gray-800 rounded-lg px-3 py-3 text-center">
            <div className={`text-2xl font-bold tabular-nums ${cls}`}>{value}</div>
            <div className="text-xs text-gray-600 font-mono mt-0.5 leading-tight">{label}</div>
          </div>
        ))}
      </div>

      {/* Promotion thresholds reminder */}
      <div className="mb-6 bg-gray-900 border border-gray-800 rounded-lg px-5 py-3 flex flex-wrap gap-4 text-xs font-mono text-gray-500">
        <span>Validation thresholds used to reach this queue:</span>
        <span>fired ≥ <span className="text-gray-300">{t.min_trigger_fired}</span></span>
        <span>support ≥ <span className="text-gray-300">{Math.round(t.min_support_rate * 100)}%</span></span>
        <span>lift ≥ <span className="text-gray-300">{t.min_lift}×</span></span>
        <span>contra ≤ <span className="text-gray-300">{Math.round(t.max_contradiction_rate * 100)}%</span></span>
      </div>

      {/* Empty state */}
      {candidates.length === 0 ? (
        <div className="bg-gray-900 border border-gray-800 rounded-xl px-6 py-10 text-center">
          <div className="text-gray-600 text-4xl mb-3">○</div>
          <div className="text-gray-400 text-sm mb-2">No candidates currently awaiting review.</div>
          <p className="text-gray-600 text-xs font-mono leading-relaxed">
            Run the Phase 4 pipeline (observations → candidates → validate → promote) to generate
            candidates. Once a candidate gets recommendation=promote_to_testing, it appears here.
          </p>
          <div className="mt-4 flex gap-3 justify-center">
            <Link href="/phase4/promotion" className="text-sm text-indigo-400 hover:text-indigo-300 font-mono">
              → Phase 4 Promotion
            </Link>
            <Link href="/phase4/candidates" className="text-sm text-indigo-400 hover:text-indigo-300 font-mono">
              → All Candidates
            </Link>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {candidates.map((cand) => {
            const vfired = (cand.validated_trigger_fired_count as number) ?? 0;
            const vrate = cand.validated_support_rate as number | null;
            const vlift = cand.validated_lift as number | null;

            return (
              <div
                key={cand.candidate_id as string}
                className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden"
              >
                {/* Card header */}
                <div className="px-5 py-4 border-b border-gray-800">
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-gray-600 font-mono mb-1">
                        {cand.candidate_id as string}
                      </div>
                      <div className="text-sm font-semibold text-gray-100 mb-2">
                        {cand.title as string}
                      </div>
                      <CandidateApprovalBadge
                        reviewStatus={(cand.review_status as string | null) ?? null}
                        forecastApproved={(cand.forecast_approved as boolean | null) ?? null}
                        autoGenerated={true}
                        size="sm"
                      />
                    </div>
                    <Link
                      href={`/phase4/candidates/${cand.candidate_id}`}
                      className="text-xs text-indigo-400 hover:text-indigo-300 font-mono flex-shrink-0"
                    >
                      full detail →
                    </Link>
                  </div>
                </div>

                {/* Stats */}
                <div className="px-5 py-4 border-b border-gray-800">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      {
                        label: 'trigger fired',
                        value: String(vfired),
                        cls: vfired >= t.min_trigger_fired ? 'text-green-400' : 'text-rose-400',
                      },
                      {
                        label: 'support rate',
                        value: vrate !== null ? `${Math.round(vrate * 100)}%` : '—',
                        cls:
                          vrate !== null && vrate >= t.min_support_rate
                            ? 'text-green-400'
                            : 'text-rose-400',
                      },
                      {
                        label: 'lift',
                        value: vlift !== null ? `${vlift.toFixed(2)}×` : '—',
                        cls:
                          vlift !== null && vlift >= t.min_lift
                            ? 'text-emerald-400'
                            : 'text-rose-400',
                      },
                      {
                        label: 'confidence',
                        value: (cand.confidence_score as number)?.toFixed(3) ?? '—',
                        cls: 'text-indigo-300',
                      },
                    ].map(({ label, value, cls }) => (
                      <div key={label} className="bg-gray-800/50 rounded p-3 text-center">
                        <div className={`text-lg font-bold font-mono tabular-nums ${cls}`}>
                          {value}
                        </div>
                        <div className="text-xs text-gray-600 font-mono">{label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Logic preview */}
                <div className="px-5 py-4 border-b border-gray-800 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-gray-600 font-mono uppercase tracking-wide mb-1">
                      Trigger
                    </div>
                    <pre className="text-xs text-indigo-300 font-mono bg-gray-800/50 rounded p-2 overflow-auto">
                      {JSON.stringify(cand.trigger_logic, null, 2)}
                    </pre>
                  </div>
                  <div>
                    <div className="text-xs text-gray-600 font-mono uppercase tracking-wide mb-1">
                      Expected
                    </div>
                    <pre className="text-xs text-green-300 font-mono bg-gray-800/50 rounded p-2 overflow-auto">
                      {JSON.stringify(cand.expected_logic, null, 2)}
                    </pre>
                  </div>
                </div>

                {/* Quick action buttons — navigate to detail for full review */}
                <div className="px-5 py-3 bg-gray-800/20 flex items-center justify-between flex-wrap gap-2">
                  <div className="text-xs text-gray-600 font-mono">
                    pattern: {cand.pattern_family as string} ·
                    rec: <span className="text-green-400">{cand.last_recommendation as string}</span>
                  </div>
                  <Link
                    href={`/phase4/candidates/${cand.candidate_id}`}
                    className="px-4 py-2 text-sm bg-indigo-700 hover:bg-indigo-600 text-white rounded-lg font-medium transition-colors"
                  >
                    Review this candidate →
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Footer nav */}
      <div className="mt-8 pt-6 border-t border-gray-800 flex flex-wrap gap-3 text-xs font-mono">
        <Link href="/phase4/promotion" className="text-indigo-400 hover:text-indigo-300">← Promotion Engine</Link>
        <Link href="/phase4/candidates" className="text-indigo-400 hover:text-indigo-300">All Candidates</Link>
        <Link href="/phase4/validation-runs" className="text-indigo-400 hover:text-indigo-300">Validation Runs</Link>
        <Link href="/phase2/hypotheses" className="text-indigo-400 hover:text-indigo-300 ml-auto">Hypothesis Registry →</Link>
      </div>
    </div>
  );
}

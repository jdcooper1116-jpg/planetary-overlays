'use client';

import { useState } from 'react';

interface ReviewActionPanelProps {
  candidateId: string;
  registryId?: string | null;
  currentReviewStatus?: string | null;
  onSuccess?: (result: Record<string, unknown>) => void;
}

type Action = 'approve' | 'reject' | 'return' | 'needs_more_data';

const ACTION_CONFIG: Record<
  Action,
  { label: string; endpoint: string; color: string; confirmMsg: string }
> = {
  approve: {
    label: '✓ Approve for Forecast Use',
    endpoint: '/api/four-pillars/phase4/approve-candidate',
    color:
      'bg-green-700 hover:bg-green-600 border-green-600 text-white disabled:bg-green-900 disabled:border-green-800',
    confirmMsg:
      'This will set forecast_approved=true and allow this hypothesis to participate in forecast generation (subject to evidence thresholds). Confirm?',
  },
  reject: {
    label: '✗ Reject Permanently',
    endpoint: '/api/four-pillars/phase4/reject-candidate',
    color:
      'bg-rose-800 hover:bg-rose-700 border-rose-700 text-white disabled:bg-rose-900 disabled:border-rose-800',
    confirmMsg:
      'This will permanently reject the candidate. It will remain visible for audit but cannot enter forecasting. Confirm?',
  },
  return: {
    label: '↩ Return to Queue',
    endpoint: '/api/four-pillars/phase4/return-candidate-to-queue',
    color:
      'bg-sky-800 hover:bg-sky-700 border-sky-700 text-white disabled:bg-sky-900 disabled:border-sky-800',
    confirmMsg:
      'This will return the candidate to the queue for re-evaluation. forecast_approved stays false. Confirm?',
  },
  needs_more_data: {
    label: '⏳ Needs More Data',
    endpoint: '/api/four-pillars/phase4/mark-candidate-needs-more-data',
    color:
      'bg-amber-800 hover:bg-amber-700 border-amber-700 text-white disabled:bg-amber-900 disabled:border-amber-800',
    confirmMsg:
      'This will flag the candidate as needing more backtest data before it can be reviewed again. Confirm?',
  },
};

export default function ReviewActionPanel({
  candidateId,
  registryId,
  currentReviewStatus,
  onSuccess,
}: ReviewActionPanelProps) {
  const [notes, setNotes] = useState('');
  const [running, setRunning] = useState<Action | null>(null);
  const [lastResult, setLastResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);

  const isReviewed =
    currentReviewStatus === 'approved' || currentReviewStatus === 'rejected';

  async function runAction(action: Action) {
    const config = ACTION_CONFIG[action];

    if (!window.confirm(config.confirmMsg)) return;

    setRunning(action);
    setError(null);
    setLastResult(null);

    try {
      const res = await fetch(config.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          candidate_id: candidateId,
          registry_id: registryId ?? undefined,
          notes: notes.trim() || null,
          reviewed_by: 'researcher',
        }),
      });

      const data = await res.json();

      if (!data.ok && data.ok !== undefined) {
        setError(data.error ?? 'Unknown error');
      } else {
        setLastResult(data);
        onSuccess?.(data);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setRunning(null);
    }
  }

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl px-6 py-5">
      <div className="text-sm font-semibold text-gray-200 mb-1">Review Actions</div>
      <p className="text-xs text-gray-500 mb-5">
        These actions are permanent. Approving sets{' '}
        <span className="font-mono text-green-400">forecast_approved=true</span> on the registry
        entry. Rejected candidates are archived, not deleted. Review notes are stored permanently.
      </p>

      {isReviewed && (
        <div className="mb-4 px-4 py-3 bg-amber-950/30 border border-amber-800/40 rounded-lg text-xs text-amber-300 font-mono">
          This candidate has already been reviewed ({currentReviewStatus}). Actions below will
          override the previous review decision.
        </div>
      )}

      {/* Notes input */}
      <div className="mb-5">
        <label className="block text-xs text-gray-500 font-mono mb-1.5">
          Review Notes (optional — stored permanently)
        </label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Reason for this decision, observations, caveats..."
          rows={3}
          className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-200 placeholder-gray-600 font-mono focus:outline-none focus:border-indigo-600 resize-none"
        />
      </div>

      {/* Action buttons */}
      <div className="grid grid-cols-2 gap-3">
        {(Object.keys(ACTION_CONFIG) as Action[]).map((action) => {
          const config = ACTION_CONFIG[action];
          const isRunning = running === action;
          return (
            <button
              key={action}
              onClick={() => runAction(action)}
              disabled={running !== null}
              className={`px-4 py-3 rounded-lg border text-sm font-medium transition-colors ${config.color} disabled:cursor-not-allowed`}
            >
              {isRunning ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-3.5 h-3.5 border border-white/40 border-t-white rounded-full animate-spin" />
                  Running…
                </span>
              ) : (
                config.label
              )}
            </button>
          );
        })}
      </div>

      {/* Result / error */}
      {error && (
        <div className="mt-4 px-4 py-3 bg-rose-950/30 border border-rose-800/50 rounded-lg text-xs text-rose-400 font-mono">
          Error: {error}
        </div>
      )}

      {lastResult && (
        <div className="mt-4 px-4 py-3 bg-green-950/30 border border-green-800/40 rounded-lg text-xs font-mono text-green-300">
          <div className="font-semibold mb-1">
            Action completed: {lastResult.action as string}
          </div>
          <div className="text-gray-400">{lastResult.message as string}</div>
          <div className="mt-2 flex gap-4 text-gray-500 flex-wrap">
            <span>
              queue: <span className="text-gray-200">{lastResult.queue_status as string}</span>
            </span>
            <span>
              registry: <span className="text-gray-200">{String(lastResult.registry_status ?? '—')}</span>
            </span>
            <span>
              forecast_approved:{' '}
              <span className={lastResult.forecast_approved ? 'text-green-400' : 'text-rose-400'}>
                {String(lastResult.forecast_approved)}
              </span>
            </span>
          </div>
          <p className="mt-2 text-gray-600">Reload the page to see updated status.</p>
        </div>
      )}
    </div>
  );
}

interface ReviewNotesFormProps {
  reviewStatus?: string | null;
  reviewDecision?: string | null;
  reviewNotes?: string | null;
  reviewedBy?: string | null;
  reviewedAt?: string | null;
}

const DECISION_LABELS: Record<string, string> = {
  approve_for_forecast: 'Approved for Forecast Use',
  reject_permanently: 'Rejected Permanently',
  return_to_queue: 'Returned to Queue',
  needs_more_data: 'Flagged: Needs More Data',
};

export default function ReviewNotesForm({
  reviewStatus,
  reviewDecision,
  reviewNotes,
  reviewedBy,
  reviewedAt,
}: ReviewNotesFormProps) {
  if (!reviewStatus || reviewStatus === 'pending') return null;

  const decisionLabel = reviewDecision ? (DECISION_LABELS[reviewDecision] ?? reviewDecision) : '—';

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl px-6 py-5">
      <div className="text-sm font-semibold text-gray-200 mb-4">Review Record</div>
      <div className="space-y-3 text-sm">
        <div className="flex gap-4">
          <span className="text-xs text-gray-600 font-mono w-36 flex-shrink-0 pt-0.5">Decision</span>
          <span className="text-gray-200 font-mono text-xs">{decisionLabel}</span>
        </div>
        <div className="flex gap-4">
          <span className="text-xs text-gray-600 font-mono w-36 flex-shrink-0 pt-0.5">Reviewed by</span>
          <span className="text-gray-200 font-mono text-xs">{reviewedBy ?? '—'}</span>
        </div>
        <div className="flex gap-4">
          <span className="text-xs text-gray-600 font-mono w-36 flex-shrink-0 pt-0.5">Reviewed at</span>
          <span className="text-gray-200 font-mono text-xs">
            {reviewedAt
              ? new Date(reviewedAt).toLocaleString('en-US', {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                })
              : '—'}
          </span>
        </div>
        {reviewNotes && (
          <div className="flex gap-4">
            <span className="text-xs text-gray-600 font-mono w-36 flex-shrink-0 pt-0.5">Notes</span>
            <span className="text-gray-300 text-xs leading-relaxed">{reviewNotes}</span>
          </div>
        )}
      </div>
    </div>
  );
}

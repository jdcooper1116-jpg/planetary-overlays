# Four Pillars — Phase 5: Forecast Governance & Outcome Tracking

## Purpose

Phase 5 turns the research system into a controlled forecasting engine:
- Generates auditable forecast runs from approved hypotheses only
- Records full decision chains (every hypothesis checked, passed/failed, triggered/not)
- Resolves forecasts against actual draw outcomes
- Tracks per-hypothesis hit/miss/neutral contributions
- Exposes performance monitoring pages

---

## File map

### New files

```
src/lib/fourPillars/phase5/
  forecastRunTypes.ts       ← canonical types for forecast_runs schema
  forecastConstants.ts      ← thresholds, versioning, hint parsing, hit detection
  forecastGenerator.ts      ← full decision-chain forecast generation
  forecastResolver.ts       ← outcome resolution + backfill
  hypothesisPerformance.ts  ← per-hypothesis performance stats from resolved runs
  forecastReaders.ts        ← Firestore reads for Phase 5 pages

src/app/api/four-pillars/phase5/
  generate-forecast/route.ts
  resolve-forecast/route.ts
  backfill-forecast-outcomes/route.ts
  hypothesis-performance/route.ts

src/app/phase5/
  layout.tsx
  forecasts/page.tsx
  forecasts/[forecastId]/page.tsx
  outcomes/page.tsx
  hypothesis-performance/page.tsx
  experiments/page.tsx

src/components/phase5/
  ForecastSummaryCard.tsx
  ForecastCandidateTable.tsx
  HypothesisContributionPanel.tsx
  OutcomeResolutionCard.tsx
  PerformanceStatCard.tsx
```

### Files that REPLACE existing versions

| File | Why |
|---|---|
| `src/components/phase2/DashboardShell.tsx` | Adds Phase 5 nav group |
| `src/lib/fourPillars/forecast/forecastEngine.ts` | Delegates to Phase 5 generator; preserves Phase 4.5 guard |

---

## Forecast guard — VERIFY after install

After copying files, run:
```bash
grep -n "forecast_approved\|auto_generated" src/lib/fourPillars/phase5/forecastGenerator.ts
```

You should see:
```
const eligibleHyps = allHyps.filter((h) => {
  if (h.auto_generated === true) return h.forecast_approved === true;
  return true;
});
```

This is the canonical Phase 4.5 hard rule. It must remain.

---

## Install order

```bash
cd /workspaces/planetary-overlays
git checkout -b feature/phase5-forecast-governance

# Extract and rsync
TOP="$(dirname "$(find /tmp/four-pillars-phase5 -type d -name src | head -n 1)")"
rsync -av "$TOP/src/" ./src/

# Verify guard
grep -n "forecast_approved" src/lib/fourPillars/phase5/forecastGenerator.ts

# Build
npm run build
rm -rf .next && npm run dev
```

---

## API usage

```bash
BASE=http://localhost:3000

# Generate a forecast for Jan 15 2024 midday
curl -X POST $BASE/api/four-pillars/phase5/generate-forecast \
  -H "Content-Type: application/json" \
  -d '{
    "game_id": "ny_pick3",
    "jurisdiction_id": "ny",
    "target_draw_date": "2024-01-15",
    "target_draw_label": "midday",
    "target_draw_time_utc": "2024-01-15T17:20:00Z"
  }'

# Resolve it (draw already mirrored)
curl -X POST $BASE/api/four-pillars/phase5/resolve-forecast \
  -H "Content-Type: application/json" \
  -d '{"forecast_id": "fp5_ny_pick3_2024-01-15_midday"}'

# Resolve with manual actual result override
curl -X POST $BASE/api/four-pillars/phase5/resolve-forecast \
  -H "Content-Type: application/json" \
  -d '{"forecast_id": "fp5_ny_pick3_2024-01-15_midday", "actual_result": "028"}'

# Backfill all unresolved forecasts
curl -X POST $BASE/api/four-pillars/phase5/backfill-forecast-outcomes \
  -H "Content-Type: application/json" \
  -d '{"game_id": "ny_pick3"}'

# Hypothesis performance
curl $BASE/api/four-pillars/phase5/hypothesis-performance
```

---

## Validation checklist

```
[ ] /phase5/forecasts loads — shows all runs + stat cards
[ ] /phase5/forecasts/[forecastId] loads — shows decision chain, candidates, outcome
[ ] /phase5/outcomes loads — shows resolved forecasts with hit types
[ ] /phase5/hypothesis-performance loads — per-hypothesis stats
[ ] /phase5/experiments loads — suggested pilot dates with generate buttons
[ ] generate-forecast creates a forecast_runs doc with status=generated
[ ] forecast_runs doc has decision_chain with one entry per eligible hypothesis
[ ] only eligible hypotheses in decision chain (auto_generated=true requires forecast_approved=true)
[ ] resolve-forecast finds actual draw and sets hit_type
[ ] resolve-forecast idempotent (already_resolved=true on second call)
[ ] backfill-forecast-outcomes resolves all generated forecasts whose draws exist
[ ] hypothesis-performance returns correct counts per hypothesis
[ ] Phase 2-4.5 pages still load without errors
[ ] npm run build passes with no TS errors
```

---

## Hit type logic

- **straight**: multiple positional candidates ALL matched in correct positions
- **box**: candidates matched the actual digits in any order
- **miss**: no candidate hints matched the actual result
- `null`: forecast had no evidence-backed candidates (never generates a hit)

A `digit_root:6` candidate hits if the actual result's digit root equals 6.
A `pos3:8` candidate hits if the third digit of the actual result is `8`.
A `structure:double` candidate hits if two of the three digits are the same.

---

## forecast_runs document shape (Phase 5)

Phase 5 adds these fields to the existing `forecast_runs` collection:
- `status` (generated/awaiting_outcome/resolved/archived)
- `decision_chain[]` — full per-hypothesis evaluation
- `approved_hypotheses_used[]`
- `triggered_hypotheses[]`
- `candidates[]` with source_hypotheses + rationale
- `context_snapshot` / `celestial_snapshot`
- `actual_result`, `actual_draw_id`, `hit_type`
- `outcome_summary` with hypothesis_contributions[]
- `forecast_method_version: "2.0.0"`

Phase 1/2 forecast docs coexist in the same collection — they just don't have the new fields.
